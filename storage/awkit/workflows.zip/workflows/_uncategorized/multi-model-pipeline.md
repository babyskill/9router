---
description: 🔗 Quy trình Đa Mô hình Tự động (v1.0)
---

# WORKFLOW: /pipeline - Multi-Model Collaborative Pipeline

Quy trình phối hợp tự động hóa đa mô hình giúp tối ưu hóa chi phí token, phân bổ đúng vai trò mô hình (Gemini Flash Medium/High, Opus 4.6, Codex CLI) và tăng tốc độ phát triển.

---

## 🧭 Tổng quan Các Bước Chạy (Core Pipeline Phases)

```mermaid
graph TD
    A[Giai đoạn 1: Context Triage - Gemini Flash Medium] -->|Đóng gói ngữ cảnh| B[Giai đoạn 2: Architecture Planning - Opus 4.6 via agy CLI]
    B -->|Xác lập PRD & Spec| C[Giai đoạn 3: Competitor Research - Research Subagent]
    C -->|Bản vẽ layout specs| D[Giai đoạn 4: Visual Design - Codex CLI]
    D -->|UI Demo Preview -> Spritesheets| E[Giai đoạn 5: Code Execution - Workers & Critic]
```

---

## 🅰️ Giai đoạn 1: Context Triage (Gemini Flash Medium)
1. **Quét nhanh hệ thống:** Đọc `CODEBASE.md`, kiểm tra Git status và lịch sử thay đổi để xác định phạm vi của tính năng mới.
2. **Triệu gọi CLI Plan:** Thực thi lệnh `awkit pipeline plan "<Feature Name>"` để bắt đầu quá trình lập kế hoạch bằng mô hình mạnh hơn.

---

## 🅱️ Giai đoạn 2: Lập kế hoạch Kiến trúc (Opus 4.6 via agy CLI)
1. **Lệnh thực thi tự động:**
   ```bash
   agy --model claude-opus --print "Thực hiện lập kế hoạch chi tiết cho tính năng '<Feature Name>'. Sử dụng codebase context sau: <context>. Tạo PRD tại docs/PRD.md và Spec tại docs/specs/<Feature>_spec.md."
   ```
2. **Sản phẩm đầu ra (Outputs):**
   - `docs/PRD.md` (Product Requirements Document).
   - `docs/specs/<Feature>_spec.md` (Technical specifications & Mermaid flowchart).
   - Kế hoạch triển khai chia theo từng Phase tại `implementation_plan.md`.

---

## 🆃 Giai đoạn 3: Nghiên cứu Đối thủ & Đặc tả (Research & Spec)
1. **Nhiệm vụ:** Worker subagent `research` quét các module đối thủ cạnh tranh hoặc tài liệu API liên quan để điền chi tiết spec.
2. **Cô lập:** Log quét thô được giải phóng, chỉ lưu giữ kết quả cô đọng trong file spec.

---

## 🅳 Giai đoạn 4: Thiết kế Giao diện Shell & Assets (Codex CLI)
1. **Pha A: UI Demo Preview**
   - Thực thi `codex exec` để tạo một mockup giao diện tĩnh hoặc SwiftUI prototype nhanh.
   - User kiểm duyệt và chốt layout.
2. **Pha B: GUI Assets & Spritesheet**
   - Thực thi `codex exec` để sinh các biểu tượng, nút bấm, egg/pet companion và spritesheet tương thích với layout đã chốt.
   - Lưu trữ các tệp assets vào thư mục `assets/ui/`.

---

## 🅴 Giai đoạn 5: Thực thi Viết Code & Kiểm thử (Gemini Workers & Critic)
1. **Coding:** Gemini Worker clones thực hiện viết code song song hoặc tuần tự cho từng Phase đã lên kế hoạch ở Bước 2.
2. **Phê bình & Đánh giá (Critic):**
   - Kích hoạt `critic` subagent thông qua lệnh `codex review --uncommitted` để kiểm tra bảo mật, logic lỗi, và SOLID principles trước khi staging/commit.
