# 🎼 Multi-Agent CLI Pipeline Workflow

> **Command Shortcut:** `/multi-agent`  
> **Central Script:** `scripts/multi-model-pipeline.js`  
> **Orchestration:** Claude (Architect) ➔ Qwen (Executor) ➔ Codex (Inspector)  

---

## 📖 Overview

Quy trình này tự động hóa việc phát triển tính năng bằng cách phân phối các bước thiết kế, code, và review cho các CLI chuyên dụng. Điều này tối ưu hóa chi phí API và cải thiện chất lượng sản phẩm cuối cùng.

---

## 🛠️ Step-by-Step Execution

### Bước 1: Khởi chạy Lập kế hoạch (Plan Phase)
Gọi Claude CLI để lập PRD và spec kiến trúc chi tiết:
```bash
awkit pipeline plan "FeatureName"
```
*Sản phẩm đầu ra:* `docs/PRD.md` và `docs/specs/feature_name_spec.md`.

### Bước 2: Thiết kế giao diện & Mockup (UI Phase)
Gọi Codex CLI để tạo demo và spritesheet/gui assets:
```bash
awkit pipeline ui "FeatureName"
```
*Sản phẩm đầu ra:* `assets/ui/demo_preview.html` và GUI assets.

### Bước 3: Viết mã nguồn (Code Phase)
Gọi Qwen Coder CLI (hoặc fallback Gemini) để thực thi viết mã và tự động chạy code review:
```bash
awkit pipeline code "FeatureName"
```
*Sản phẩm đầu ra:* Source code hoàn thiện và báo cáo review chi tiết.

---

## 🔔 Sound Notifications

Sau khi mỗi Phase (Plan, UI, Code) hoàn tất, hệ thống sẽ tự động phát âm thanh thông báo hệ thống và giọng nói (trên macOS) để báo hiệu cho người dùng biết khi nào task background kết thúc:
- `afplay /System/Library/Sounds/Glass.aiff`
- `say "[Phase] đã hoàn thành"`

---

## 🚫 Fallback Policy

- Nếu Claude CLI bị lỗi ➔ Tự động chuyển sang sử dụng `agy --model claude-opus` (Gemini CLI).
- Nếu Qwen CLI bị lỗi ➔ Tự động chuyển sang sử dụng `agy --model gemini-2.5-flash` (Gemini CLI).
- Quy trình không bị dừng hoặc crash giữa chừng, đảm bảo sự liên tục.
