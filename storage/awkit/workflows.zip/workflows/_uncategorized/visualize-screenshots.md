# /screenshots — App Store Screenshot Generator

**Purpose**: Kích hoạt quy trình thiết kế và tạo bộ ảnh Screenshot cho App Store và Google Play.

## 🚀 Workflow

### 1. Thu thập thông tin (Discovery)
- AI sẽ chào mừng người dùng và yêu cầu các thông tin cần thiết:
    - Screenshot thực tế của App (PNG).
    - App Icon.
    - Màu sắc thương hiệu và Font mong muốn.
    - Danh sách tính năng cốt lõi (theo thứ tự ưu tiên).
    - Số lượng Slide mục tiêu.

### 2. Thiết kế nội dung (Copywriting)
- AI đề xuất các Headline cho từng Slide dựa trên quy tắc **"Một tích tắc - Một ý tưởng"**.
- Chờ người dùng duyệt nội dung trước khi chuyển sang bước Code.

### 3. Triển khai kỹ thuật (Scaffolding)
- AI khởi tạo dự án Next.js (nếu cần) hoặc tạo file `src/app/screenshots/page.tsx` trong dự án hiện tại.
- Cài đặt dependency `html-to-image`.
- Cấu hình layout, device frames và logic export.

### 4. Kiểm thử và Xuất bản (Export)
- Chụp ảnh màn hình thử nghiệm.
- Kiểm tra độ phân giải của file export (6.9", 6.5", Tablet, v.v.).

---

> [!TIP]
> **Pro-tip**: Screenshots là quảng cáo, không phải hướng dẫn sử dụng. Để AI tập trung vào "Cảm xúc" và "Kết quả" mà ứng dụng mang lại.

> [!IMPORTANT]
> **Trigger**: Lệnh này sẽ tự động kích hoạt skill `app-store-screenshots`.
