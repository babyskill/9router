---
description: 🎨 Image Generator — Tạo App Icons, Mascots và Pets (Hatch-style) với chất lượng Studio (Soft-Edge & Hole-Aware)
---

# /image-gen — High-Quality Asset Production Workflow

> Quy trình tạo Asset chuyên nghiệp, tự động tách nền và xử lý cạnh mượt mà (PicWish Style).
> Hỗ trợ tạo Pet Bundle (Trứng + Thú cưng) tương tự Codex nhưng chất lượng cao hơn.

// turbo-all

---

## Sub-commands

### `/image-gen:icon` — Tạo bộ App Icon

1. Hỏi user về chủ đề (Theme), phong cách (Style - mặc định: `vector`), và **Kích thước lưới** (Grid - mặc định: `3x3`).
2. Tự động tính toán số lượng `{count}` dựa trên lưới (vd: 3x3 -> 9 icons).
3. Thông báo user: "🎨 Đang phác thảo bộ Icon Set {grid} cho chủ đề: {theme}..."
4. Thực thi lệnh tạo:
```bash
create-icon {theme} {grid} {style}
```
5. Sau khi ảnh được tạo, thông báo: "✅ Đã tạo xong và xử lý Soft-Edge. File lưu tại: `assets/generated/`."

### `/image-gen:mascot` — Tạo bộ Linh vật / Mascot

1. Hỏi user về nhân vật (Character), phong cách (Style - mặc định: `chibi`), và **Kích thước lưới** (Grid - mặc định: `3x3`).
2. Tự động tính toán số lượng `{count}` dựa trên lưới.
3. Thông báo user: "🧸 Đang thiết kế bộ Mascot {grid} cho: {character}..."
4. Thực thi lệnh tạo:
```bash
create-mascot {character} {grid} {style}
```
5. Sau khi ảnh được tạo, thông báo: "✅ Mascot đã sẵn sàng với nền trong suốt hoàn hảo!"

### `/image-gen:pet` — Tạo Pet Bundle (Ấp trứng)

1. Hỏi user về loại Pet (ví dụ: `fire dragon`, `ice phoenix`) và **Kích thước lưới** (Grid - mặc định: `4x4` cho đầy đủ trạng thái).
2. Thông báo user: "🐣 Đang tạo Pet Bundle ({grid}) cho: {pet_type}..."
3. Thực thi lệnh tạo:
```bash
create-pet {pet_type} {grid}
```
4. Tạo thư mục cấu hình: `mkdir -p assets/pets/{pet_id}`
5. Ghi file `pet.json` mẫu tương thích hệ thống Hatch Pet.
6. Thông báo: "✨ Pet Bundle đã được đóng gói tại `assets/pets/{pet_id}/`."

### `/image-gen:process` — Xử lý ảnh có sẵn (Hole-Aware)

1. User cung cấp đường dẫn ảnh nguồn (`input_path`).
2. Xác định tên file đầu ra (`output_name.webp`).
3. Thực thi lệnh xử lý với thuật toán v3.1:
```bash
process-image {input_path} assets/generated/{output_name}.webp 15
```

### `/image-gen:openrouter` — Tạo ảnh qua OpenRouter (GPT-5.4-Image)

Quy trình sử dụng script `openrouter_image_gen.py` (Codex-grade) hỗ trợ 3 chế độ:

#### 1. Chế độ `generate` (Text-to-Image)
Dùng để tạo mới asset từ mô tả văn bản, hỗ trợ các tham số Art Direction cực mạnh:
```bash
python3 ~/.gemini/antigravity/scripts/openrouter_image_gen.py generate \
  --prompt "{chủ_thể}" \
  --style "{phong_cách}" \
  --lighting "{ánh_sáng}" \
  --palette "{tông_màu}" \
  --out "assets/generated/{filename}.webp"
```

#### 2. Chế độ `edit` (Image-to-Image / Style Transfer)
Dùng để biến đổi ảnh có sẵn (Local path hoặc URL) sang phong cách khác hoặc chỉnh sửa chi tiết:
```bash
python3 ~/.gemini/antigravity/scripts/openrouter_image_gen.py edit \
  --image "{đường_dẫn_ảnh_gốc}" \
  --prompt "{mô_tả_chỉnh_sửa}" \
  --style "{phong_cách_mới}" \
  --out "assets/generated/{filename}.webp"
```

#### 3. Chế độ `generate-batch` (Chạy hàng loạt)
Dùng để sinh hàng loạt asset từ file `.jsonl` (tối đa 100 jobs) với cơ chế Retry tự động:
```bash
python3 ~/.gemini/antigravity/scripts/openrouter_image_gen.py generate-batch \
  --input "jobs.jsonl" \
  --out-dir "assets/generated/batch/" \
  --concurrency 3
```

> **Note**: Script tự động xử lý Upload ảnh local lên `tmpfiles.org` và có cơ chế Exponential Backoff để chống lỗi nghẽn (429).

---

## 🛠 Quality Standards (Codex Hatch Pet Technique)

- **🚫 CẤM DÙNG "Nền trong suốt / Transparent Background"**: TUYỆT ĐỐI KHÔNG thêm các từ khóa "transparent background", "nền trong suốt", "alpha channel" vào prompt sinh ảnh. Việc này sẽ khiến AI (như DALL-E, Midjourney, OpenRouter) sinh ra **nền caro giả (fake checkerboard)** bám dính vào nhân vật, cực kỳ khó xoá.
- **✅ Background**: LUÔN ưu tiên sử dụng `solid bright green background #00FF00` hoặc `solid white background #FFFFFF` (nếu nhân vật có màu xanh) để AI render chi tiết tốt nhất, không bị đổ bóng (no shadows cast on the background).
- **🛠 Hậu kỳ (Post-Processing)**: Sau khi sinh ảnh thô có nền Solid, BẮT BUỘC sử dụng công cụ Python Chroma-key cục bộ (process-image hoặc process_sprites.py) để gỡ nền.
- **Edges & Holes**: Script Python sẽ tự động áp dụng Alpha Feathering (Blur 0x3) để triệt tiêu răng cưa, và xóa các vùng kẹt trong cánh/tay nhưng bảo vệ đôi mắt (Morphology Close).

---

## Communication

Mỗi khi bắt đầu một lượt generate:
```
🎨 [Antigravity Artist] Đang khởi tạo xưởng vẽ cho {asset_type}...
🚀 Chiến lược: Neutral White + Soft-Edge Alpha.
```

Sau khi hoàn tất:
```
✅ Hoàn tất! Asset của bạn đã được tối ưu hóa WebP và tách nền sạch sẽ.
📍 Vị trí: [đường dẫn]
```
