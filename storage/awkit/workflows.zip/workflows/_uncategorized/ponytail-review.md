---
description: Review code hoặc diff để phát hiện over-engineering. Chỉ ra code thừa, stdlib bị viết lại, dependency không cần thiết.
alwaysApply: false
priority: "medium"
---

# Ponytail Review — Over-Engineering Audit

## 🎯 Mục đích

Quét code/diff để tìm các điểm phức tạp không cần thiết. Không review logic/security — chỉ hunt complexity.

## 🔧 Quy trình thực hiện

### Bước 1: Xác định phạm vi
- Nếu user chỉ định file/directory → quét đó.
- Nếu không → quét diff hiện tại (`git diff --staged` hoặc `git diff`).
- Nếu không có diff → quét toàn bộ `src/` hoặc thư mục code chính.

### Bước 2: Áp dụng Ponytail Ladder ngược
Với mỗi đoạn code, kiểm tra:
1. **Có cần tồn tại không?** → Tag `delete:` nếu speculative/dead.
2. **Stdlib đã có?** → Tag `stdlib:` + tên hàm stdlib thay thế.
3. **Native platform có?** → Tag `native:` + tên feature thay thế.
4. **Abstraction duy nhất?** → Tag `yagni:` nếu interface/factory/wrapper chỉ có 1 implementation.
5. **Có thể ngắn hơn?** → Tag `shrink:` + đoạn code rút gọn.

### Bước 3: Output format
```
L<line>: <tag> <what>. <replacement>.
```
Hoặc multi-file:
```
<file>:L<line>: <tag> <what>. <replacement>.
```

### Bước 4: Tổng kết
```
net: -<N> lines possible.
```
Nếu code đã tối giản: `Lean already. Ship.`

## 📋 Ví dụ Output

```
L12-38: stdlib: 27-line email validator. "@" in email, 1 line.
L4: native: moment.js for one format call. Intl.DateTimeFormat, 0 deps.
utils.py:L88: yagni: AbstractRepository, 1 impl. Inline it.
L52-71: delete: retry wrapper on idempotent local call. Nothing.
L30-44: shrink: manual loop → dict(zip(keys, values)), 1 line.

net: -87 lines possible.
```

## ⚠️ Ranh giới

- KHÔNG flag smoke tests hoặc assert-based self-checks — đó là ponytail minimum.
- KHÔNG sửa code — chỉ liệt kê findings.
- Correctness bugs, security holes → dùng review workflow khác.
