---
description: "🎨 Tạo pixel art từ mô tả ngôn ngữ tự nhiên (Aseprite + pixel-mcp)"
---

# Pixel Gen — Generate Pixel Art from Description

## Input
User provides description via `$ARGUMENTS`. Examples:
- `/pixel-gen 32x32 gameboy character sprite`
- `/pixel-gen 64x64 pico8 sword with shading`
- `/pixel-gen 16x16 nes brick tile`
- `/pixel-gen 48x48 mascot idle animation 4 frames`

## Parse Arguments

Extract from description:
1. **Size**: Look for `WxH` pattern (default: 64x64)
2. **Palette**: Look for palette names: `gameboy`, `nes`, `pico8`, `c64`, `sweetie16`, `db16`, `db32` (default: RGB)
3. **Subject**: The main thing to draw (character, sword, tile, mascot, etc.)
4. **Style modifiers**: `shading`, `dithering`, `antialiasing`, `outline`
5. **Animation**: Look for `animation`, `frames`, `idle`, `walk`, `run` + frame count

## Workflow

### Step 1: Read the aseprite-artist Skill
Read `~/.gemini/antigravity/skills/aseprite-artist/SKILL.md` for full tool reference.

If a palette is specified, also read `~/.gemini/antigravity/skills/aseprite-artist/resources/palettes.md` for hex values.

### Step 2: Canvas Setup
1. Call `mcp__aseprite__create_canvas` with parsed width, height, color_mode
2. If retro palette detected → call `mcp__aseprite__set_palette` with palette hex colors
3. Add layers as needed (Background, Subject, Effects)

### Step 3: Draw
Use the MCP drawing tools to create the described subject:
- Start with silhouette shapes (`draw_rectangle`, `draw_circle`, `draw_contour`)
- Fill with colors (`fill_area`)
- Add details with individual pixels (`draw_pixels`)
- Apply dithering if requested (`draw_with_dither`)

### Step 4: Polish (if requested)
- Apply shading: `mcp__aseprite__apply_auto_shading`
- Apply antialiasing: `mcp__aseprite__suggest_antialiasing`
- Apply outline: `mcp__aseprite__apply_outline`

### Step 5: Animate (if requested)
- Add frames: `mcp__aseprite__add_frame`
- Set timing: `mcp__aseprite__set_frame_duration`
- Tag sequence: `mcp__aseprite__create_tag`

### Step 6: Export
Default exports:
- **Static sprite**: Export as PNG at 2x scale to project directory or `./pixel-output/`
- **Animated sprite**: Export as GIF + PNG spritesheet
- **Game asset**: Export spritesheet (grid) + JSON metadata

```bash
mkdir -p ./pixel-output
```

### Step 7: Report
Show user what was created:
```
✅ Pixel Art Created
- File: ./pixel-output/[name].png
- Size: [W]x[H] @ [scale]x
- Palette: [palette name] ([N] colors)
- Frames: [N] (if animated)
- Export: [format list]

Preview: [describe what was drawn]
```

## Quick Reference — Common Patterns

| Input Pattern | Action |
|---------------|--------|
| `WxH` | Set canvas size |
| `gameboy/nes/pico8/c64` | Set retro palette + Indexed mode |
| `character/sprite/icon` | Draw subject |
| `shading/shadow` | Apply auto-shading |
| `dithering/dither` | Apply dithering pattern |
| `animation/idle/walk N frames` | Create N-frame animation |
| `tile` | 16x16 or 32x32, tileable |
| `mascot` | 64x64+, detailed character |
