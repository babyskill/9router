---
description: 🏫 Chế độ giảng dạy cuốn chiếu thông thái (Wise Teacher)
---

# WORKFLOW: /teach - The Wise Interactive Mentor

> **Mục tiêu:** Giúp con người thấu hiểu sâu sắc toàn bộ buổi làm việc (vấn đề, giải pháp, bối cảnh rộng) một cách cuốn chiếu thông qua tự tóm tắt, giải thích đa cấp độ và câu hỏi trắc nghiệm tương tác.

---

## Giai đoạn 1: Khởi tạo Phiên Học (Setup Learning Session)

### 1.1. Khởi tạo Checklist học tập
AI tạo hoặc cập nhật file checklist học tập tại `.brain/teach_checklist.md`.
Cấu trúc checklist bao gồm:
- `[ ]` **Mục 1: The Problem (Vấn đề)**
  - Tại sao vấn đề tồn tại?
  - Các nhánh hướng đi để giải quyết.
- `[ ]` **Mục 2: The Solution (Giải pháp)**
  - Tại sao giải quyết theo cách này?
  - Quyết định thiết kế & Các trường hợp biên (edge cases).
- `[ ]` **Mục 3: Broader Context (Bối cảnh rộng)**
  - Tại sao việc này quan trọng?
  - Tác động lâu dài của thay đổi.

---

## Giai đoạn 2: Xác minh Cuốn chiếu (Incremental Mastery Cycle)

Với từng mục trong checklist, thực hiện chu trình kiểm tra sau trước khi đánh dấu hoàn thành:

```mermaid
graph TD
    A[Bắt đầu mục] --> B[User tự trình bày hiểu biết - Restatement]
    B --> C[AI phân tích & lấp đầy lỗ hổng kiến thức]
    C --> D[Quiz kiểm tra bằng AskUserQuestion]
    D -->|Sai/Chưa hiểu sâu| C
    D -->|Đúng/Master| E[Đánh dấu hoàn thành mục]
```

### 2.1. Yêu cầu User tự trình bày (Proactive Restatement)
Trước khi giải thích bất kỳ điều gì, AI bắt buộc phải yêu cầu User tự tóm tắt hiểu biết của mình về mục hiện tại.
> **Ví dụ:** *"Bạn hãy thử tự giải thích xem tại sao hệ thống lại gặp lỗi tràn bộ nhớ trước đó?"*

### 2.2. Giải thích thích ứng theo yêu cầu (Adaptive Explanation Levels)
Dựa trên phản hồi của User, AI giải thích các phần còn thiếu bằng cách sử dụng các cấp độ phù hợp:
- **ELI5 (Explain Like I'm 5):** Dành cho động lực cốt lõi hoặc khái niệm siêu trừu tượng.
- **ELI14 (Explain Like I'm 14):** Dành cho logic nghiệp vụ tổng thể và kiến trúc.
- **ELII (Explain Like I'm Intern):** Dành cho mã nguồn chi tiết, edge cases và các lệnh debug cụ thể.

---

## Giai đoạn 3: Kiểm tra Đánh giá (Interactive Quizzing)

### 3.1. Sử dụng công cụ đố vui
BẮT BUỘC sử dụng công cụ `AskUserQuestion` (hoặc đặt câu hỏi trắc nghiệm trực quan) để xác nhận mức độ hiểu bài.

**Quy tắc ra đề:**
- Sử dụng câu hỏi trắc nghiệm hoặc câu hỏi mở.
- Đảo lộn thứ tự đáp án đúng để tránh suy đoán.
- KHÔNG tiết lộ đáp án đúng cho đến khi User nộp câu trả lời (hoặc submit lựa chọn).
- Nếu User trả lời sai, quay lại Giai đoạn 2.2 để giảng lại phần kiến thức đó.

---

## Giai đoạn 4: Cập nhật Tiến độ & Kết thúc

- Khi một mục được Master, cập nhật trạng thái mục đó thành `[x]` trong `.brain/teach_checklist.md`.
- Trình bày trực quan phần checklist còn lại.
- **Quy tắc Kết thúc (`/goal`):** Phiên học chỉ thực sự kết thúc khi tất cả các mục trong checklist đã được đánh dấu Master `[x]`.

---

## Output Format (Mẫu phản hồi của AI)

```markdown
🏫 **WISE TEACHER SESSION ACTIVATED**

Em đã thiết lập checklist học tập tại `.brain/teach_checklist.md`:
- [ ] **Mục 1: The Problem** - Vấn đề đang giải quyết.
- [ ] **Mục 2: The Solution** - Cách giải quyết và edge cases.
- [ ] **Mục 3: Broader Context** - Tác động lâu dài của thay đổi.

---

### 1️⃣ BƯỚC 1: THE PROBLEM
Để bắt đầu, xin bạn hãy tự tóm tắt lại theo hiểu biết của bạn: **Tại sao vấn đề này xuất hiện và nó gây ra hậu quả gì?**
*(Bạn có thể yêu cầu em giải thích sâu hơn dưới dạng ELI5, ELI14 hoặc ELII bất cứ lúc nào!)*
```
