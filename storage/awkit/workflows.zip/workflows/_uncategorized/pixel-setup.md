---
description: "🎮 Setup pixel-mcp MCP Server cho Aseprite pixel art"
---

# Pixel Setup — First-Time Configuration

## Prerequisites Check

1. **Verify Aseprite installation:**
```bash
# macOS
ls -la /Applications/Aseprite.app/Contents/MacOS/aseprite 2>/dev/null && echo "✅ Aseprite found" || echo "❌ Aseprite not found"

# Linux
which aseprite 2>/dev/null && echo "✅ Aseprite found" || echo "❌ Aseprite not found"
```

2. **Detect Aseprite path:**
- macOS: `/Applications/Aseprite.app/Contents/MacOS/aseprite`
- Linux: `/usr/bin/aseprite` or `/usr/local/bin/aseprite`
- Windows: `C:\Program Files\Aseprite\Aseprite.exe`

If Aseprite not found, inform user:
> ⚠️ Aseprite chưa được cài đặt. Tải từ https://www.aseprite.org/ (có phí) hoặc build từ source (miễn phí).

## Step 1: Install pixel-mcp

```bash
# Option A: Download pre-built binary from GitHub Releases
# https://github.com/willibrandon/pixel-mcp/releases

# Option B: Build from source (requires Go 1.23+)
git clone https://github.com/willibrandon/pixel-mcp.git /tmp/pixel-mcp-build
cd /tmp/pixel-mcp-build
make build
mkdir -p ~/.local/bin
cp bin/pixel-mcp ~/.local/bin/pixel-mcp
chmod +x ~/.local/bin/pixel-mcp
echo "✅ pixel-mcp installed to ~/.local/bin/pixel-mcp"
```

## Step 2: Create Configuration

```bash
mkdir -p ~/.config/pixel-mcp
cat > ~/.config/pixel-mcp/config.json << 'PIXEL_CONFIG'
{
  "aseprite_path": "/Applications/Aseprite.app/Contents/MacOS/aseprite",
  "temp_dir": "/tmp/pixel-mcp",
  "timeout": 30,
  "log_level": "info"
}
PIXEL_CONFIG
echo "✅ Config created at ~/.config/pixel-mcp/config.json"
```

**Note:** If user provides Aseprite path as argument `$1`, use that instead of the default macOS path.

## Step 3: Verify MCP Server

```bash
~/.local/bin/pixel-mcp --health 2>&1 || echo "⚠️ Health check failed — may need Aseprite path correction"
```

## Step 4: Add to MCP Config (if not already present)

Check if `aseprite` entry exists in the user's MCP config. If not, add it:

```json
{
  "aseprite": {
    "command": "~/.local/bin/pixel-mcp",
    "args": []
  }
}
```

## Done

Report to user:
```
✅ Pixel MCP Setup Complete
- Aseprite: [detected path]
- pixel-mcp: ~/.local/bin/pixel-mcp
- Config: ~/.config/pixel-mcp/config.json
- Status: [health check result]

Bạn có thể bắt đầu tạo pixel art bằng cách mô tả. Ví dụ:
"Tạo một sprite Game Boy 32x32 của một nhân vật"
```
